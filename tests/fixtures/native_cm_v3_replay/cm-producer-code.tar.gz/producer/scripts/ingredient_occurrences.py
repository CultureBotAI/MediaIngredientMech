"""Lossless direct ingredient-occurrence collection and aggregation (#337).

The source corpus has two root record contracts.  MediaRecipe-shaped records
own ``ingredients``; SolutionRecipe-shaped records own ``composition``.  This
module selects exactly one of those fields, adds the ``composition`` of every
inline stock nested in the record's ``solutions[]`` (#604; a reference to a
standalone solution record in the same scan is not expanded, #312), records
every direct descriptor with stable coordinates, and resolves its identity
through the pinned MediaIngredientMech label index introduced by #260.

Structured variant changes (#683) add only ADD/SET_CONCENTRATION/new REPLACE
descriptors to the positive occurrence table. Every change, including REMOVE
and the old REPLACE descriptor, is retained separately with its exact source
context. No base formulation is expanded, subtracted from, or materialized.

The TSV occurrence artifact is canonical.  The mapped and unmapped YAML files
are deterministic compatibility views derived from the same in-memory rows.
Input errors are collected before any successful artifact is replaced.
"""

from __future__ import annotations

import csv
import json
import os
import stat
import tempfile
from collections import Counter, defaultdict
from collections.abc import Callable, Container, Mapping, Sequence
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, TextIO, cast

import yaml
from linkml.validator.report import Severity
from record_kinds import has_solution_shape
from validate_strict import _get_validator, classify, infer_target_class

from culturemech.ingredients.mim_label_index import (
    GroundingDecision,
    ResolutionSource,
    resolve_ingredient,
)
from culturemech.validation.variant_ingredients import variant_ingredient_validation_results

VARIANT_CONTEXT_FIELDS = (
    "variant_index",
    "variant_name",
    "change_index",
    "change_action",
    "change_stage",
    "descriptor_role",
    "descriptor_path",
    "source_modification_index",
    "source_text",
    "evidence_json",
    "change_json",
)

OCCURRENCE_FIELDS = (
    "recipe_id",
    "recipe_label",
    "recipe_category",
    "source_path",
    "record_class",
    "component_field",
    "component_index",
    "preferred_term",
    "label_source",
    "resolved_identifier",
    "resolution_source",
    "local_identifier",
    "source_compound_id",
    "mim_preferred_term",
    "mim_matched_label",
    "mim_match_type",
    "mim_mapping_status",
    "mim_ambiguity",
    "mim_ontology_id_diagnostic",
    "grounding_reason",
    "concentration_value",
    "concentration_unit",
    "ingredient_json",
) + VARIANT_CONTEXT_FIELDS
VARIANT_CHANGE_FIELDS = OCCURRENCE_FIELDS + ("counts_as_presence",)
ERROR_FIELDS = ("file", "layer", "category", "detail", "path", "message")
INGREDIENT_LIST_FIELDS = (
    "preferred_term",
    "resolved_identifier",
    "identifier_prefix",
    "mapping_status",
    "occurrence_count",
    "distinct_recipe_count",
    "label_variant_count",
    "label_variants",
    "resolution_sources",
    "recipe_categories",
)
LIST_SEPARATOR = " | "


@dataclass(frozen=True)
class AggregationError:
    """One row in the shared machine-readable error report."""

    file: str
    layer: str
    category: str
    detail: str
    path: str
    message: str

    def as_dict(self) -> dict[str, str]:
        return {field: str(getattr(self, field)) for field in ERROR_FIELDS}


@dataclass(frozen=True)
class IngredientOccurrence:
    """One direct root-recipe ingredient descriptor and its grounding audit."""

    recipe_id: str
    recipe_label: str
    recipe_category: str
    source_path: str
    record_class: str
    component_field: str
    component_index: int
    preferred_term: str
    label_source: str
    resolved_identifier: str
    resolution_source: str
    local_identifier: str
    source_compound_id: str
    mim_preferred_term: str
    mim_matched_label: str
    mim_match_type: str
    mim_mapping_status: str
    mim_ambiguity: str
    mim_ontology_id_diagnostic: str
    grounding_reason: str
    concentration_value: str
    concentration_unit: str
    ingredient_json: str
    variant_index: int | str = ""
    variant_name: str = ""
    change_index: int | str = ""
    change_action: str = ""
    change_stage: str = ""
    descriptor_role: str = ""
    descriptor_path: str = ""
    source_modification_index: int | str = ""
    source_text: str = ""
    evidence_json: str = ""
    change_json: str = ""

    @property
    def key(self) -> tuple[str, str, int]:
        """Stable occurrence coordinate within the CultureMech corpus."""

        return self.recipe_id, self.component_field, self.component_index

    @property
    def sort_key(self) -> tuple[Any, ...]:
        """``key`` in document order, so ``solutions/2`` sorts before ``solutions/10``."""

        return self.recipe_id, _field_order(self.component_field), self.component_index

    @property
    def is_resolved(self) -> bool:
        return bool(self.resolved_identifier)

    @property
    def counts_as_presence(self) -> bool:
        """Positive direct descriptor, never a removed/replaced-old mention.

        A positive variant row is scoped to its asserted action and stage. It
        does not establish the ingredient's presence in the base recipe or a
        complete resulting formulation (including zero-concentration events).
        """

        return not self.change_action or (
            self.descriptor_role == "ingredient"
            and self.change_action in {"ADD", "SET_CONCENTRATION", "SET_AMOUNT", "REPLACE"}
        )

    @property
    def ingredient_label(self) -> str:
        """Compatibility alias for callers that use the longer field name."""

        return self.preferred_term

    @property
    def grounding_id(self) -> str:
        """Compatibility alias; ``resolved_identifier`` is the canonical name."""

        return self.resolved_identifier

    def as_dict(self) -> dict[str, str | int]:
        return {field: getattr(self, field) for field in OCCURRENCE_FIELDS}


@dataclass(frozen=True)
class ScanResult:
    """Complete deterministic scan result, including all fatal input errors."""

    occurrences: tuple[IngredientOccurrence, ...]
    errors: tuple[AggregationError, ...]
    variant_changes: tuple[IngredientOccurrence, ...] = ()
    variant_mentions: tuple[dict[str, Any], ...] = ()


HELD_MENTION_FIELDS = (
    "recipe_id",
    "recipe_label",
    "recipe_category",
    "source_path",
    "variant_index",
    "variant_name",
    "mention_index",
    "descriptor_path",
    "source_label",
    "reported_action",
    "stage",
    "source_modification_index",
    "source_text",
    "reason",
    "reported_quantity",
    "held_fields_json",
    "evidence_json",
    "mention_json",
    "review_status",
    "counts_as_presence",
)


Resolver = Callable[[Mapping[str, Any]], GroundingDecision]


def _cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return str(value)


def _error(
    source_path: str,
    category: str,
    message: str,
    *,
    path: str = "",
    detail: str = "",
    layer: str = "occurrence",
) -> AggregationError:
    return AggregationError(
        file=source_path,
        layer=layer,
        category=category,
        detail=detail,
        path=path,
        message=message[:300],
    )


def _schema_errors(instance: dict[str, Any], source_path: str) -> list[AggregationError]:
    try:
        report = _get_validator().validate(
            instance,
            target_class=infer_target_class(instance),
        )
    except Exception as exc:  # noqa: BLE001 - preserve validate-strict's failure contract
        return [
            _error(
                source_path,
                "validator_crash",
                str(exc),
                detail=type(exc).__name__,
                layer="schema",
            )
        ]
    errors: list[AggregationError] = []
    for result in report.results:
        if result.severity != Severity.ERROR:
            continue
        category, detail = classify(result.message)
        errors.append(
            _error(
                source_path,
                category,
                result.message,
                detail=detail,
                path=result.instance_index or "",
                layer="schema",
            )
        )
    if not errors:
        for result in variant_ingredient_validation_results(instance):
            if result.severity == Severity.ERROR:
                errors.append(
                    _error(
                        source_path,
                        "invalid_variant_ingredient_change",
                        result.message,
                        path=str(result.context[0]) if result.context else "",
                        layer="semantic",
                    )
                )
    return errors


def _recipe_label(instance: Mapping[str, Any], record_class: str) -> tuple[str, str]:
    preferred = instance.get("preferred_term")
    if isinstance(preferred, str) and preferred.strip():
        return preferred, "preferred_term"
    name = instance.get("name")
    if record_class == "MediaRecipe" and isinstance(name, str) and name.strip():
        return name, "legacy_name"
    return "", "blank"


def _decision_value(value: str | None) -> str:
    return value or ""


def _occurrence_from_descriptor(
    *,
    recipe_id: str,
    recipe_label: str,
    recipe_label_source: str,
    recipe_category: str,
    source_path: str,
    record_class: str,
    component_field: str,
    component_index: int,
    descriptor: Mapping[str, Any],
    resolver: Resolver,
) -> IngredientOccurrence:
    label_value = descriptor.get("preferred_term")
    label = label_value if isinstance(label_value, str) else ""
    decision = resolver(descriptor)
    concentration = descriptor.get("concentration")
    if not isinstance(concentration, Mapping):
        concentration = {}
    return IngredientOccurrence(
        recipe_id=recipe_id,
        recipe_label=recipe_label,
        recipe_category=recipe_category,
        source_path=source_path,
        record_class=record_class,
        component_field=component_field,
        component_index=component_index,
        preferred_term=label,
        label_source=recipe_label_source,
        resolved_identifier=_decision_value(decision.identifier),
        resolution_source=decision.resolution_source.value,
        local_identifier=_decision_value(decision.local_identifier),
        source_compound_id=_decision_value(decision.source_compound_id),
        mim_preferred_term=_decision_value(decision.mim_preferred_term),
        mim_matched_label=_decision_value(decision.matched_label),
        mim_match_type=_decision_value(decision.match_type),
        mim_mapping_status=_decision_value(decision.mapping_status),
        mim_ambiguity=_decision_value(decision.ambiguity),
        mim_ontology_id_diagnostic=_decision_value(decision.ontology_id),
        grounding_reason=decision.reason,
        concentration_value=_cell(concentration.get("value")),
        concentration_unit=_cell(concentration.get("unit")),
        ingredient_json=json.dumps(
            dict(descriptor),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
    )


def _field_order(component_field: str) -> tuple[tuple[int, int | str], ...]:
    """Order ``component_field`` paths by position rather than character by character."""

    return tuple(
        (0, int(part)) if part.isdigit() else (1, part) for part in component_field.split("/")
    )


def _references_scanned_record(
    solution: Mapping[str, Any],
    scanned_records: Container[str],
    solution_records: Container[str],
) -> bool:
    """Whether an inline solution names a record that is part of the same scan.

    Same precedence as ``kgx_export.nested_solution_target``: a
    ``culturemech_term`` naming a record, then a ``term.id`` that a standalone
    solution record carries. A ``culturemech_term`` naming no record in the scan
    falls back to the ``term.id``, so a stale local link cannot count a scanned
    stock's components a second time.
    """
    local = solution.get("culturemech_term")
    if isinstance(local, Mapping) and str(local.get("id", "")) in scanned_records:
        return True
    term = solution.get("term")
    term_id = term.get("id") if isinstance(term, Mapping) else None
    return isinstance(term_id, str) and term_id in solution_records


def _inline_solution_compositions(
    owner: Mapping[str, Any],
    is_reference: Callable[[Mapping[str, Any]], bool],
    prefix: str = "",
) -> list[tuple[str, Any]]:
    """``(component_field, composition)`` for every inline stock nested in ``owner``.

    A recipe's ``solutions[]`` may hold stocks that exist nowhere else; #577 moved
    2,175 ingredients of 360 media into them, and until #604 none of those reached
    the occurrence table. They belong to this recipe alone, so their components
    are direct occurrences of it, kept apart from root ingredients by a
    path-shaped ``component_field`` such as ``solutions/0/composition``.

    Walking stops at a reference to a record in the same scan, which contributes
    its own components there: expanding the reference would count them once per
    medium (#312). Content an inline copy carries beyond its referenced record is
    not counted; #607 and #609 track those copies. An inline stock with an empty
    ``preferred_term`` is still counted, although the KGX export cannot mint a
    node for it.
    """
    found: list[tuple[str, Any]] = []
    solutions = owner.get("solutions")
    if not isinstance(solutions, list):
        return found
    for index, solution in enumerate(solutions):
        if not isinstance(solution, Mapping) or is_reference(solution):
            continue
        path = f"{prefix}solutions/{index}"
        if "composition" in solution:
            found.append((f"{path}/composition", solution.get("composition")))
        found.extend(_inline_solution_compositions(solution, is_reference, f"{path}/"))
    return found


def scan_ingredient_occurrences(
    input_dir: str | Path,
    resolver: Resolver = resolve_ingredient,
) -> ScanResult:
    """Scan all YAML roots and collect their authoritative direct components.

    Every file is parsed and checked against the same closed LinkML schema used
    by ``validate_strict.py``.  Any error makes the scan unsuitable for
    publication, but all files are still visited so the error report is
    complete.

    Root components are collected while the files are read. Inline stocks are
    collected afterwards, once the scan knows every record it covers: a nested
    reference is skipped only when its record is one of them, wherever the
    referenced file sits below the input directory.
    """

    root = Path(input_dir)
    if not root.is_dir():
        return ScanResult(
            occurrences=(),
            errors=(
                _error(
                    root.as_posix(),
                    "invalid_input_dir",
                    "input directory does not exist or is not a directory",
                ),
            ),
        )

    occurrences: list[IngredientOccurrence] = []
    variant_changes: list[IngredientOccurrence] = []
    variant_mentions: list[dict[str, Any]] = []
    errors: list[AggregationError] = []
    seen_keys: dict[tuple[str, str, int], str] = {}
    seen_recipe_ids: dict[str, str] = {}
    # Every record whose components this scan collects, and the standalone
    # solution ``term.id`` values among them: built from the parsed records
    # themselves, not from a second index of the files.
    scanned_records: set[str] = set()
    solution_records: set[str] = set()
    pending: list[tuple[dict[str, str], Mapping[str, Any]]] = []

    def emit(context: Mapping[str, str], component_field: str, components: Sequence[Any]) -> None:
        source_path = context["source_path"]
        for index, descriptor in enumerate(components):
            descriptor_path = f"/{component_field}/{index}"
            if not isinstance(descriptor, Mapping):
                errors.append(
                    _error(
                        source_path,
                        "invalid_component",
                        "ingredient descriptor must be a mapping",
                        path=descriptor_path,
                    )
                )
                continue
            try:
                occurrence = _occurrence_from_descriptor(
                    **context,
                    component_field=component_field,
                    component_index=index,
                    descriptor=descriptor,
                    resolver=resolver,
                )
            except Exception as exc:  # noqa: BLE001 - report instead of silently skipping
                errors.append(
                    _error(
                        source_path,
                        "resolver_error",
                        str(exc),
                        path=descriptor_path,
                        detail=type(exc).__name__,
                    )
                )
                continue
            previous_path = seen_keys.get(occurrence.key)
            if previous_path is not None:
                errors.append(
                    _error(
                        source_path,
                        "duplicate_occurrence_key",
                        "stable occurrence coordinate also appears in " + previous_path,
                        path=descriptor_path,
                        detail="|".join(map(str, occurrence.key)),
                    )
                )
                continue
            seen_keys[occurrence.key] = source_path
            occurrences.append(occurrence)

    def emit_variant_changes(context: Mapping[str, str], instance: Mapping[str, Any]) -> None:
        # Closed-schema and shared semantic validation have already established
        # the action, source-index/text, evidence and descriptor contracts.
        for variant_index, variant in enumerate(instance.get("variants") or []):
            component_field = f"variants/{variant_index}/ingredient_changes"
            for change_index, change in enumerate(variant.get("ingredient_changes") or []):
                for role in ("ingredient", "replaced_ingredient"):
                    if role not in change:
                        continue
                    descriptor_path = f"/{component_field}/{change_index}/{role}"
                    try:
                        row = _occurrence_from_descriptor(
                            **context,
                            component_field=component_field,
                            component_index=change_index,
                            descriptor=change[role],
                            resolver=resolver,
                        )
                    except Exception as exc:  # noqa: BLE001 - complete error report
                        errors.append(
                            _error(
                                context["source_path"],
                                "resolver_error",
                                str(exc),
                                path=descriptor_path,
                                detail=type(exc).__name__,
                            )
                        )
                        continue
                    row = replace(
                        row,
                        variant_index=variant_index,
                        variant_name=variant["name"],
                        change_index=change_index,
                        change_action=change["action"],
                        change_stage=change["stage"],
                        descriptor_role=role,
                        descriptor_path=descriptor_path,
                        source_modification_index=change["source_modification_index"],
                        source_text=change["source_text"],
                        evidence_json=_cell(change["evidence"]),
                        change_json=_cell(change),
                    )
                    variant_changes.append(row)
                    if row.counts_as_presence:
                        if row.key in seen_keys:
                            errors.append(
                                _error(
                                    context["source_path"],
                                    "duplicate_occurrence_key",
                                    "stable variant occurrence coordinate is not unique",
                                    path=descriptor_path,
                                )
                            )
                            continue
                        seen_keys[row.key] = context["source_path"]
                        occurrences.append(row)

    def emit_variant_mentions(context: Mapping[str, str], instance: Mapping[str, Any]) -> None:
        for variant_index, variant in enumerate(instance.get("variants") or []):
            for mention_index, mention in enumerate(variant.get("ingredient_mentions") or []):
                row = {
                    field: context[field]
                    for field in ("recipe_id", "recipe_label", "recipe_category", "source_path")
                }
                row.update(
                    {
                        "variant_index": variant_index,
                        "variant_name": variant["name"],
                        "mention_index": mention_index,
                        "descriptor_path": f"/variants/{variant_index}/ingredient_mentions/{mention_index}",
                        **{
                            field: mention.get(field, "")
                            for field in (
                                "source_label",
                                "reported_action",
                                "stage",
                                "source_modification_index",
                                "source_text",
                                "reason",
                                "reported_quantity",
                            )
                        },
                        "evidence_json": _cell(mention.get("evidence", [])),
                        "held_fields_json": _cell(mention["held_fields"]),
                        "mention_json": _cell(mention),
                        "review_status": "WITHHELD",
                        "counts_as_presence": "false",
                    }
                )
                variant_mentions.append(row)

    files = sorted(root.rglob("*.yaml"), key=lambda item: item.as_posix())
    if not files:
        return ScanResult(
            occurrences=(),
            errors=(
                _error(
                    root.as_posix(),
                    "no_input_files",
                    "input directory contains no YAML files",
                ),
            ),
        )

    for path in files:
        source_path = path.relative_to(root).as_posix()
        try:
            instance = yaml.safe_load(path.read_text(encoding="utf-8"))
        except UnicodeDecodeError as exc:
            errors.append(
                _error(
                    source_path,
                    "input_decode_error",
                    str(exc),
                    detail="expected UTF-8",
                    layer="schema",
                )
            )
            continue
        except yaml.YAMLError as exc:
            errors.append(
                _error(
                    source_path,
                    "yaml_parse_error",
                    str(exc).splitlines()[0],
                    layer="schema",
                )
            )
            continue
        except OSError as exc:
            errors.append(
                _error(
                    source_path,
                    "input_read_error",
                    str(exc),
                    detail=type(exc).__name__,
                )
            )
            continue

        if instance is None:
            errors.append(
                _error(
                    source_path,
                    "empty_file",
                    "file parsed as None",
                    layer="schema",
                )
            )
            continue
        if not isinstance(instance, dict):
            errors.append(
                _error(
                    source_path,
                    "invalid_record_root",
                    "root YAML value must be a mapping",
                )
            )
            continue

        validation_errors = _schema_errors(instance, source_path)
        if validation_errors:
            errors.extend(validation_errors)
            continue

        record_class = "SolutionRecipe" if has_solution_shape(instance) else "MediaRecipe"
        component_field = "composition" if record_class == "SolutionRecipe" else "ingredients"
        recipe_id_value = instance.get("id")
        if not isinstance(recipe_id_value, str) or not recipe_id_value.strip():
            errors.append(
                _error(
                    source_path,
                    "missing_recipe_id",
                    "root record has no usable CultureMech id",
                    path="/id",
                )
            )
            continue
        recipe_id = recipe_id_value.strip()
        previous_recipe_path = seen_recipe_ids.get(recipe_id)
        if previous_recipe_path is not None:
            errors.append(
                _error(
                    source_path,
                    "duplicate_recipe_id",
                    f"root recipe id also appears in {previous_recipe_path}",
                    path="/id",
                    detail=recipe_id,
                )
            )
            continue
        seen_recipe_ids[recipe_id] = source_path
        recipe_label, recipe_label_source = _recipe_label(instance, record_class)
        if not recipe_label:
            errors.append(
                _error(
                    source_path,
                    "missing_recipe_label",
                    "root record has no canonical display label",
                    path="/preferred_term" if record_class == "SolutionRecipe" else "/name",
                )
            )
            continue

        components = instance.get(component_field)
        if not isinstance(components, list):
            errors.append(
                _error(
                    source_path,
                    "invalid_component_collection",
                    f"{component_field} must be a list",
                    path=f"/{component_field}",
                )
            )
            continue

        recipe_category = _cell(instance.get("category") or "UNKNOWN").upper()
        context = {
            "recipe_id": recipe_id,
            "recipe_label": recipe_label,
            "recipe_label_source": recipe_label_source,
            "recipe_category": recipe_category,
            "source_path": source_path,
            "record_class": record_class,
        }
        emit(context, component_field, components)
        emit_variant_changes(context, instance)
        emit_variant_mentions(context, instance)
        scanned_records.add(recipe_id)
        if record_class == "SolutionRecipe":
            solution_records.add(instance["term"]["id"])
        if instance.get("solutions"):
            pending.append((context, instance))

    def is_reference(solution: Mapping[str, Any]) -> bool:
        return _references_scanned_record(solution, scanned_records, solution_records)

    for context, owner in pending:
        for nested_field, nested in _inline_solution_compositions(owner, is_reference):
            if not isinstance(nested, list):
                errors.append(
                    _error(
                        context["source_path"],
                        "invalid_component_collection",
                        f"{nested_field} must be a list",
                        path=f"/{nested_field}",
                    )
                )
                continue
            emit(context, nested_field, nested)

    occurrences.sort(key=lambda row: row.sort_key + (row.source_path,))
    variant_changes.sort(key=lambda row: row.sort_key + (row.descriptor_role, row.source_path))
    errors.sort(
        key=lambda row: (
            row.file,
            row.layer,
            row.path,
            row.category,
            row.message,
        )
    )
    variant_mentions.sort(
        key=lambda row: (row["recipe_id"], row["variant_index"], row["mention_index"])
    )
    return ScanResult(
        tuple(occurrences), tuple(errors), tuple(variant_changes), tuple(variant_mentions)
    )


def _write_tsv(
    stream: TextIO,
    fieldnames: Sequence[str],
    rows: Sequence[Mapping[str, Any]],
) -> None:
    writer = csv.DictWriter(
        stream,
        fieldnames=fieldnames,
        delimiter="\t",
        quoting=csv.QUOTE_MINIMAL,
        lineterminator="\n",
    )
    writer.writeheader()
    writer.writerows(rows)


def _write_occurrences_stream(
    stream: TextIO,
    occurrences: Sequence[IngredientOccurrence],
) -> None:
    writer = csv.DictWriter(
        stream,
        fieldnames=OCCURRENCE_FIELDS,
        delimiter="\t",
        quoting=csv.QUOTE_MINIMAL,
        lineterminator="\n",
    )
    writer.writeheader()
    for row in occurrences:
        writer.writerow(row.as_dict())


def _write_errors_stream(stream: TextIO, errors: Sequence[AggregationError]) -> None:
    _write_tsv(stream, ERROR_FIELDS, [row.as_dict() for row in errors])


def _write_variant_changes_stream(stream: TextIO, changes: Sequence[IngredientOccurrence]) -> None:
    writer = csv.DictWriter(
        stream, fieldnames=VARIANT_CHANGE_FIELDS, delimiter="\t", lineterminator="\n"
    )
    writer.writeheader()
    for row in changes:
        writer.writerow(
            {**row.as_dict(), "counts_as_presence": "true" if row.counts_as_presence else "false"}
        )


def _safe_dump(value: Any, stream: TextIO) -> None:
    yaml.safe_dump(
        value,
        stream,
        allow_unicode=True,
        sort_keys=False,
        default_flow_style=False,
    )


def _write_yaml_collection_stream(stream: TextIO, value: Mapping[str, Any]) -> None:
    """Write one top-level collection without representing its full row list.

    PyYAML constructs an in-memory representation graph for a whole value before
    emitting it.  Dumping each top-level list entry separately preserves the
    same YAML data model and ordering while keeping the 200k-row mapped view
    within a practical memory bound.
    """

    scalar_values = {key: item for key, item in value.items() if not isinstance(item, list)}
    if scalar_values:
        _safe_dump(scalar_values, stream)
    for key, items in value.items():
        if not isinstance(items, list):
            continue
        if not items:
            stream.write(f"{key}: []\n")
            continue
        stream.write(f"{key}:\n")
        for item in items:
            _safe_dump([item], stream)


ArtifactWriter = Callable[[TextIO], None]


def _stage_writer(path: Path, writer: ArtifactWriter) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    )
    staged = Path(handle.name)
    try:
        with handle:
            writer(cast(TextIO, handle))
            handle.flush()
            os.fsync(handle.fileno())
        mode = stat.S_IMODE(path.stat().st_mode) if path.exists() else 0o644
        staged.chmod(mode)
    except Exception:
        staged.unlink(missing_ok=True)
        raise
    return staged


def _backup_destination(path: Path) -> Path | None:
    if not path.exists():
        return None
    descriptor, backup_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".bak",
    )
    os.close(descriptor)
    backup = Path(backup_name)
    backup.unlink()
    os.link(path, backup)
    return backup


def _atomic_write_many(artifacts: Sequence[tuple[Path, ArtifactWriter]]) -> None:
    resolved_destinations = [destination.resolve() for destination, _writer in artifacts]
    if len(resolved_destinations) != len(set(resolved_destinations)):
        raise ValueError("artifact destinations must be distinct")
    staged: list[tuple[Path, Path]] = []
    backups: dict[Path, Path | None] = {}
    replaced: list[Path] = []
    try:
        for destination, writer in artifacts:
            staged.append((_stage_writer(destination, writer), destination))
        for _temporary, destination in staged:
            backups[destination] = _backup_destination(destination)
        for temporary, destination in staged:
            os.replace(temporary, destination)
            replaced.append(destination)
    except Exception:
        for destination in reversed(replaced):
            backup = backups.get(destination)
            if backup is None:
                destination.unlink(missing_ok=True)
            else:
                os.replace(backup, destination)
        raise
    finally:
        for temporary, _destination in staged:
            temporary.unlink(missing_ok=True)
        for backup in backups.values():
            if backup is not None:
                backup.unlink(missing_ok=True)


def write_occurrences_tsv(
    path: str | Path,
    occurrences: Sequence[IngredientOccurrence],
) -> None:
    """Atomically write the canonical, uncapped occurrence table."""

    _atomic_write_many(
        [(Path(path), lambda stream: _write_occurrences_stream(stream, occurrences))]
    )


def write_error_report(path: str | Path, errors: Sequence[AggregationError]) -> None:
    """Atomically write the shared error header even when there are no rows."""

    _atomic_write_many([(Path(path), lambda stream: _write_errors_stream(stream, errors))])


def write_yaml_output(path: str | Path, value: Mapping[str, Any]) -> None:
    """Atomically write one deterministic compatibility-view YAML file."""

    _atomic_write_many([(Path(path), lambda stream: _write_yaml_collection_stream(stream, value))])


def write_occurrences_and_yaml(
    occurrences_path: str | Path,
    occurrences: Sequence[IngredientOccurrence],
    yaml_path: str | Path,
    value: Mapping[str, Any],
    list_path: str | Path | None = None,
    *,
    variant_changes: Sequence[IngredientOccurrence] = (),
    changes_path: str | Path | None = None,
    variant_mentions: Sequence[Mapping[str, Any]] = (),
    holds_path: str | Path | None = None,
) -> None:
    """Publish a compatibility wrapper's outputs as one staged set.

    The ingredient list is derived from the same occurrences, so refreshing it
    here keeps it consistent with the occurrence table (#512).
    """

    _atomic_write_many(
        [
            (
                Path(occurrences_path),
                lambda stream: _write_occurrences_stream(stream, occurrences),
            ),
            (
                Path(yaml_path),
                lambda stream: _write_yaml_collection_stream(stream, value),
            ),
            (
                (
                    Path(changes_path)
                    if changes_path is not None
                    else default_changes_output(occurrences_path)
                ),
                lambda stream: _write_variant_changes_stream(stream, variant_changes),
            ),
            (
                (
                    Path(holds_path)
                    if holds_path is not None
                    else default_holds_output(occurrences_path)
                ),
                lambda stream: _write_tsv(stream, HELD_MENTION_FIELDS, variant_mentions),
            ),
            *(
                [
                    (
                        Path(list_path),
                        lambda stream: _write_ingredient_list_stream(stream, occurrences),
                    )
                ]
                if list_path is not None
                else []
            ),
        ]
    )


def default_list_output(occurrences_output: str | Path) -> Path:
    """Place the ingredient list beside the occurrence table it is derived from."""

    return Path(occurrences_output).parent / "ingredients_list.tsv"


def default_changes_output(occurrences_output: str | Path) -> Path:
    """Place the lossless variant-change ledger beside positive occurrences."""

    return Path(occurrences_output).parent / "variant_ingredient_changes.tsv"


def default_holds_output(occurrences_output: str | Path) -> Path:
    """Keep unresolved names outside positive occurrence and mapping assertions."""
    return Path(occurrences_output).parent / "variant_ingredient_holds.tsv"


def ensure_distinct_output_paths(*paths: str | Path) -> None:
    """Reject CLI output aliases before any error or success artifact is touched."""

    resolved = [Path(path).resolve() for path in paths]
    if len(resolved) != len(set(resolved)):
        raise ValueError("ingredient aggregation output paths must be distinct")


def _occurrence_dict(row: IngredientOccurrence) -> dict[str, Any]:
    occurrence = {
        "recipe_id": row.recipe_id,
        "recipe_label": row.recipe_label,
        "recipe_category": row.recipe_category,
        "source_path": row.source_path,
        "component_field": row.component_field,
        "component_index": row.component_index,
        "preferred_term": row.preferred_term,
        "resolution_source": row.resolution_source,
        "grounding_reason": row.grounding_reason,
    }
    optional = {
        "resolved_identifier": row.resolved_identifier,
        "source_compound_id": row.source_compound_id,
        "local_identifier": row.local_identifier,
        "mim_preferred_term": row.mim_preferred_term,
        "mim_matched_label": row.mim_matched_label,
        "mim_match_type": row.mim_match_type,
        "mim_mapping_status": row.mim_mapping_status,
        "mim_ambiguity": row.mim_ambiguity,
        "mim_ontology_id_diagnostic": row.mim_ontology_id_diagnostic,
    }
    occurrence.update({key: value for key, value in optional.items() if value})
    if row.change_action:
        occurrence.update({field: getattr(row, field) for field in VARIANT_CONTEXT_FIELDS})
    return occurrence


def _ingredient(row: IngredientOccurrence) -> dict[str, Any]:
    value = json.loads(row.ingredient_json)
    if not isinstance(value, dict):  # pragma: no cover - constructor guarantees it
        raise TypeError("ingredient_json must encode a mapping")
    return value


def _concentration_rows(rows: Sequence[IngredientOccurrence]) -> list[dict[str, str]]:
    unique: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in rows:
        ingredient = _ingredient(row)
        notes = _cell(ingredient.get("notes"))
        if not row.concentration_value and not row.concentration_unit and not notes:
            continue
        key = row.concentration_value, row.concentration_unit, notes
        unique[key] = {
            "value": row.concentration_value,
            "unit": row.concentration_unit,
            "notes": notes,
        }
    return [unique[key] for key in sorted(unique)]


def _ontology_source(identifier: str) -> str:
    prefix = identifier.partition(":")[0].upper()
    if prefix in {"CHEBI", "FOODON", "NCIT", "MESH", "UBERON", "ENVO"}:
        return prefix
    return "OTHER"


_TRUSTED_MIM_SOURCES = frozenset(
    {ResolutionSource.MIM_EXACT.value, ResolutionSource.MIM_NORMALIZED.value}
)


def _most_common(values: Sequence[str]) -> str:
    """Return the most frequent non-empty value; ties break by code point."""

    counts = Counter(value for value in values if value)
    return min(counts, key=lambda value: (-counts[value], value)) if counts else ""


def _canonical_term(rows: Sequence[IngredientOccurrence]) -> str:
    """Name one resolved identity (#509, #529).

    Only rows that MIM resolved directly contribute MIM terms: on fallback rows,
    ``mim_preferred_term`` belongs to the label's (possibly ambiguous) MIM match,
    not necessarily to the resolved identifier.  Among those, terms MIM marks
    ``MAPPED`` outrank its ``REJECTED`` preferred terms, so an accepted hydrate
    spelling is not outvoted by a rejected generic one (CHEBI:32142).  Within a
    tier the most frequent term wins; ties break by code point.
    """

    trusted = [row for row in rows if row.resolution_source in _TRUSTED_MIM_SOURCES]
    return (
        _most_common(
            [row.mim_preferred_term for row in trusted if row.mim_mapping_status == "MAPPED"]
        )
        or _most_common([row.mim_preferred_term for row in trusted])
        or _most_common([row.preferred_term for row in rows])
        or rows[0].resolved_identifier
    )


def _mapping_quality(rows: Sequence[IngredientOccurrence]) -> str:
    match_types = {row.mim_match_type for row in rows if row.mim_match_type}
    resolution_sources = {row.resolution_source for row in rows}
    if match_types & {"synonym", "ontology_label"} or ResolutionSource.MIM_NORMALIZED.value in (
        resolution_sources
    ):
        return "SYNONYM_MATCH"
    if resolution_sources <= {
        ResolutionSource.MIM_EXACT.value,
        ResolutionSource.MIM_NORMALIZED.value,
    }:
        return "DIRECT_MATCH"
    return "INFERRED"


def _category_summary(
    rows: Sequence[IngredientOccurrence],
    *,
    mapped: bool,
) -> list[dict[str, Any]]:
    by_category: dict[str, list[IngredientOccurrence]] = defaultdict(list)
    for row in rows:
        by_category[row.recipe_category or "UNKNOWN"].append(row)
    summary: list[dict[str, Any]] = []
    for category in sorted(by_category):
        category_rows = by_category[category]
        unique_keys = {
            row.resolved_identifier if mapped else _unmapped_group_key(row) for row in category_rows
        }
        summary.append(
            {
                "category": category,
                "recipes_with_mapped" if mapped else "recipes_with_unmapped": len(
                    {row.recipe_id for row in category_rows}
                ),
                "total_mapped_instances" if mapped else "total_unmapped_instances": len(
                    category_rows
                ),
                "unique_mapped_count" if mapped else "unique_unmapped_count": len(unique_keys),
            }
        )
    return summary


def build_mapped_output(
    occurrences: Sequence[IngredientOccurrence],
    min_occurrences: int = 1,
) -> dict[str, Any]:
    """Build the identity-first mapped compatibility view."""

    groups: dict[str, list[IngredientOccurrence]] = defaultdict(list)
    for row in occurrences:
        if row.counts_as_presence and row.is_resolved:
            groups[row.resolved_identifier].append(row)

    entries: list[dict[str, Any]] = []
    included_rows: list[IngredientOccurrence] = []
    for identifier, group in groups.items():
        rows = sorted(group, key=lambda row: row.sort_key + (row.source_path,))
        if len(rows) < min_occurrences:
            continue
        included_rows.extend(rows)
        canonical_term = _canonical_term(rows)
        source_labels = sorted({row.preferred_term for row in rows if row.preferred_term})
        entries.append(
            {
                "preferred_term": canonical_term,
                "resolved_identifier": identifier,
                "ontology_label": canonical_term,
                "ontology_source": _ontology_source(identifier),
                "occurrence_count": len(rows),
                "distinct_recipe_count": len({row.recipe_id for row in rows}),
                "recipe_occurrences": [_occurrence_dict(row) for row in rows],
                "concentration_info": _concentration_rows(rows),
                "synonyms": [label for label in source_labels if label != canonical_term],
                "mapping_quality": _mapping_quality(rows),
            }
        )

    entries.sort(key=lambda entry: (-entry["occurrence_count"], entry["resolved_identifier"]))
    ontology_rows: dict[str, list[IngredientOccurrence]] = defaultdict(list)
    for row in included_rows:
        ontology_rows[_ontology_source(row.resolved_identifier)].append(row)
    total = len(included_rows)
    ontology_summary = []
    for source in sorted(ontology_rows):
        rows = ontology_rows[source]
        ontology_summary.append(
            {
                "ontology_source": source,
                "unique_terms_count": len({row.resolved_identifier for row in rows}),
                "total_instances": len(rows),
                "coverage_percentage": round((len(rows) * 100.0 / total), 6) if total else 0.0,
            }
        )
    return {
        "total_mapped_count": len(entries),
        "total_instances": total,
        "recipe_count": len({row.recipe_id for row in included_rows}),
        "mapped_ingredients": entries,
        "summary_by_category": _category_summary(included_rows, mapped=True),
        "summary_by_ontology": ontology_summary,
    }


def _unmapped_group_key(row: IngredientOccurrence) -> tuple[str, ...]:
    if not row.preferred_term.strip():
        return (
            "blank",
            row.recipe_id,
            row.component_field,
            str(row.component_index),
        )
    return (
        "label",
        row.preferred_term,
        row.resolution_source,
        row.mim_mapping_status,
        row.mim_ambiguity,
    )


def _unmapped_status(rows: Sequence[IngredientOccurrence]) -> str:
    if any(row.resolution_source == ResolutionSource.AMBIGUOUS.value for row in rows):
        return "AMBIGUOUS"
    return "UNMAPPED"


def build_unmapped_output(
    occurrences: Sequence[IngredientOccurrence],
    min_occurrences: int = 1,
) -> dict[str, Any]:
    """Build the unresolved compatibility view without dropping blank labels."""

    groups: dict[tuple[str, ...], list[IngredientOccurrence]] = defaultdict(list)
    for row in occurrences:
        if row.counts_as_presence and not row.is_resolved:
            groups[_unmapped_group_key(row)].append(row)

    entries: list[dict[str, Any]] = []
    included_rows: list[IngredientOccurrence] = []
    for key, group in groups.items():
        rows = sorted(group, key=lambda row: row.sort_key + (row.source_path,))
        if len(rows) < min_occurrences:
            continue
        included_rows.extend(rows)
        first = rows[0]
        notes = sorted(
            {
                _cell(_ingredient(row).get("notes"))
                for row in rows
                if _cell(_ingredient(row).get("notes"))
            }
        )
        placeholder_id = (
            first.preferred_term
            if first.preferred_term.strip()
            else f"blank:{first.recipe_id}:{first.component_field}:{first.component_index}"
        )
        entries.append(
            {
                "preferred_term": first.preferred_term,
                "placeholder_id": placeholder_id,
                "raw_ingredient_text": notes,
                "parsed_chemical_name": first.preferred_term or (notes[0] if notes else ""),
                "occurrence_count": len(rows),
                "distinct_recipe_count": len({row.recipe_id for row in rows}),
                "recipe_occurrences": [_occurrence_dict(row) for row in rows],
                "concentration_info": _concentration_rows(rows),
                "mapping_status": _unmapped_status(rows),
                "_sort_key": key,
            }
        )

    entries.sort(
        key=lambda entry: (
            -entry["occurrence_count"],
            entry["preferred_term"],
            entry["placeholder_id"],
            entry["_sort_key"],
        )
    )
    for entry in entries:
        entry.pop("_sort_key")
    return {
        "total_unmapped_count": len(entries),
        "total_instances": len(included_rows),
        "recipe_count": len({row.recipe_id for row in included_rows}),
        "unmapped_ingredients": entries,
        "summary_by_category": _category_summary(included_rows, mapped=False),
    }


def build_ingredient_list(
    occurrences: Sequence[IngredientOccurrence],
) -> list[dict[str, Any]]:
    """Build the complete one-row-per-ingredient list.

    Groups use the same keys as the mapped and unmapped views, so the row count
    equals ``total_mapped_count + total_unmapped_count`` when those views are
    built with ``min_occurrences=1``.  No ``min_occurrences`` filter applies here.
    """

    groups: dict[tuple[str, ...], list[IngredientOccurrence]] = defaultdict(list)
    for row in occurrences:
        if not row.counts_as_presence:
            continue
        key = ("mapped", row.resolved_identifier) if row.is_resolved else _unmapped_group_key(row)
        groups[key].append(row)

    entries: list[tuple[tuple[Any, ...], dict[str, Any]]] = []
    for key, rows in groups.items():
        mapped = key[0] == "mapped"
        first = rows[0]
        if mapped:
            term = _canonical_term(rows)
            status = "MAPPED"
        else:
            term = (
                f"blank:{first.recipe_id}:{first.component_field}:{first.component_index}"
                if key[0] == "blank"
                else first.preferred_term
            )
            status = _unmapped_status(rows)
        labels = sorted({row.preferred_term for row in rows if row.preferred_term})
        entry = {
            "preferred_term": term,
            "resolved_identifier": first.resolved_identifier if mapped else "",
            "identifier_prefix": first.resolved_identifier.partition(":")[0] if mapped else "",
            "mapping_status": status,
            "occurrence_count": len(rows),
            "distinct_recipe_count": len({row.recipe_id for row in rows}),
            "label_variant_count": len(labels),
            "label_variants": LIST_SEPARATOR.join(labels),
            "resolution_sources": LIST_SEPARATOR.join(
                sorted({row.resolution_source for row in rows})
            ),
            "recipe_categories": LIST_SEPARATOR.join(
                sorted({row.recipe_category or "UNKNOWN" for row in rows})
            ),
        }
        sort_key = (-entry["distinct_recipe_count"], -entry["occurrence_count"], term, key)
        entries.append((sort_key, entry))
    entries.sort(key=lambda item: item[0])
    return [entry for _, entry in entries]


def _write_ingredient_list_stream(
    stream: TextIO,
    occurrences: Sequence[IngredientOccurrence],
) -> None:
    _write_tsv(stream, INGREDIENT_LIST_FIELDS, build_ingredient_list(occurrences))


def run_aggregation(
    input_dir: str | Path,
    occurrences_output: str | Path,
    mapped_output: str | Path,
    unmapped_output: str | Path,
    errors_output: str | Path,
    min_occurrences: int = 1,
    verbose: bool = False,
    resolver: Resolver = resolve_ingredient,
    list_output: str | Path | None = None,
    changes_output: str | Path | None = None,
    holds_output: str | Path | None = None,
) -> int:
    """Scan once and publish all deterministic views, or only the error report."""

    if min_occurrences < 1:
        raise ValueError("min_occurrences must be at least 1")
    changes_output = changes_output or default_changes_output(occurrences_output)
    holds_output = holds_output or default_holds_output(occurrences_output)
    ensure_distinct_output_paths(
        occurrences_output,
        mapped_output,
        unmapped_output,
        errors_output,
        changes_output,
        holds_output,
        *([list_output] if list_output is not None else []),
    )
    result = scan_ingredient_occurrences(input_dir, resolver=resolver)
    write_error_report(errors_output, result.errors)
    if result.errors:
        if verbose:
            print(
                f"Ingredient aggregation failed with {len(result.errors)} input error(s); "
                f"see {errors_output}"
            )
        return 1

    mapped = build_mapped_output(result.occurrences, min_occurrences=min_occurrences)
    unmapped = build_unmapped_output(result.occurrences, min_occurrences=min_occurrences)
    _atomic_write_many(
        [
            (
                Path(occurrences_output),
                lambda stream: _write_occurrences_stream(stream, result.occurrences),
            ),
            (
                Path(mapped_output),
                lambda stream: _write_yaml_collection_stream(stream, mapped),
            ),
            (
                Path(unmapped_output),
                lambda stream: _write_yaml_collection_stream(stream, unmapped),
            ),
            (
                Path(changes_output),
                lambda stream: _write_variant_changes_stream(stream, result.variant_changes),
            ),
            (
                Path(holds_output),
                lambda stream: _write_tsv(stream, HELD_MENTION_FIELDS, result.variant_mentions),
            ),
            *(
                [
                    (
                        Path(list_output),
                        lambda stream: _write_ingredient_list_stream(stream, result.occurrences),
                    )
                ]
                if list_output is not None
                else []
            ),
        ]
    )
    if verbose:
        print(
            "Ingredient aggregation complete: "
            f"{len(result.occurrences)} occurrences, "
            f"{mapped['total_instances']} mapped, {unmapped['total_instances']} unmapped"
        )
        if list_output is not None:
            print(f"Ingredient list: {list_output}")
    return 0
