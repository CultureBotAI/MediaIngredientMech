"""
Browser data exporter for CultureMech.

Generates JavaScript data file for the faceted search browser.
Extracts searchable fields and facets from YAML recipes.
"""

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import yaml

from culturemech.render_media_pages import slug_for


class BrowserExporter:
    """Export recipes to browser-friendly JavaScript format."""

    def __init__(self, kb_dir: Path):
        self.kb_dir = Path(kb_dir)
        self.recipes: list[dict[str, Any]] = []

    def load_recipes(self) -> None:
        """Load all recipe YAML files."""
        if not self.kb_dir.is_dir():
            raise FileNotFoundError(f"recipe directory not found: {self.kb_dir}")

        failures: list[str] = []
        for recipe_file in sorted(self.kb_dir.rglob("*.yaml")):
            try:
                with open(recipe_file) as f:
                    recipe_data = yaml.safe_load(f)
                    if not isinstance(recipe_data, dict):
                        raise ValueError("recipe must be a YAML mapping")
                    if not recipe_data.get("id"):
                        raise ValueError("recipe has no id")
                    # Enrich with metadata
                    recipe_data["_source_file"] = str(recipe_file.relative_to(self.kb_dir))
                    recipe_data["_category"] = recipe_file.parent.name
                    self.recipes.append(recipe_data)
            except Exception as e:
                failures.append(f"{recipe_file}: {e}")

        if failures:
            details = "\n".join(f"  - {failure}" for failure in failures[:10])
            raise ValueError(
                f"failed to load {len(failures)} recipe(s); browser data was not written:\n"
                f"{details}"
            )
        if not self.recipes:
            raise ValueError(f"no recipe YAML files found under {self.kb_dir}")

    def extract_browser_data(self) -> list[dict[str, Any]]:
        """Extract flattened data for browser consumption."""
        browser_data = []

        for recipe in self.recipes:
            # Extract category, skipping "imported" (not a real category)
            category = recipe.get("category", recipe.get("_category", "unknown"))
            if category == "imported":
                # Infer from directory if still "imported"
                category = recipe.get("_category", "unknown")

            item = {
                "id": recipe.get("id"),
                "name": recipe.get("name", "Unknown"),
                "category": category.lower() if category else "unknown",
                "description": recipe.get("description", "").strip(),
                "medium_type": (recipe.get("medium_type", "") or "").lower(),
                "physical_state": (recipe.get("physical_state", "") or "").lower(),
                # Metal and REE classification
                "high_metal": recipe.get("high_metal", False),
                "high_ree": recipe.get("high_ree", False),
                # Organisms (extract names for faceting)
                "target_organism_names": self._extract_organism_names(recipe),
                "organism_culture_type": recipe.get("organism_culture_type", ""),
                "organism_ids": self._extract_organism_ids(recipe),
                # Ingredients (extract names for faceting)
                "ingredient_names": self._extract_ingredient_names(recipe),
                # Applications
                "applications": recipe.get("applications", []),
                # Sterilization
                "sterilization_method": self._extract_sterilization_method(recipe),
                # Media database
                "media_database": self._extract_media_database(recipe),
                "media_database_id": self._extract_media_database_id(recipe),
                # Counts
                "num_ingredients": len(recipe.get("ingredients", [])),
                "num_solutions": len(recipe.get("solutions", [])),
                "num_preparation_steps": len(recipe.get("preparation_steps", [])),
                # Links
                "source_file": recipe.get("_source_file", ""),
                "html_page": (
                    "normalized/"
                    + slug_for(recipe, Path(recipe.get("_source_file", "recipe.yaml")))
                    + ".html"
                ),
                # pH
                "ph_value": recipe.get("ph_value"),
                "ph_range": recipe.get("ph_range", ""),
            }

            browser_data.append(item)

        return browser_data

    def _extract_organism_names(self, recipe: dict) -> list[str]:
        """Extract organism names from target_organisms."""
        names = []
        for org in recipe.get("target_organisms", []):
            preferred_term = org.get("preferred_term")
            if preferred_term:
                names.append(preferred_term)
        return names

    def _extract_organism_ids(self, recipe: dict) -> list[str]:
        """Extract NCBITaxon and GTDB IDs from target_organisms."""
        ids = []
        for org in recipe.get("target_organisms", []):
            term = org.get("term") or {}
            if term.get("id"):
                ids.append(term["id"])
            gtdb = org.get("gtdb_term") or {}
            if gtdb.get("id"):
                ids.append(gtdb["id"])
        return ids

    def _extract_ingredient_names(self, recipe: dict) -> list[str]:
        """
        Extract ingredient names from both ingredients and solutions.

        For solutions, includes:
        - The solution name itself
        - Names of ingredients within the solution (if composition is present)

        This enables searching for media by solution components.
        """
        names = []

        # Extract from main ingredients
        for ing in recipe.get("ingredients", []):
            preferred_term = ing.get("preferred_term")
            if preferred_term:
                names.append(preferred_term)

        # Extract from solutions
        for solution in recipe.get("solutions", []):
            # Add the solution name
            solution_name = solution.get("preferred_term")
            if solution_name:
                names.append(solution_name)

            # Add ingredients within the solution (if composition is present)
            for comp in solution.get("composition", []):
                comp_name = comp.get("preferred_term")
                if comp_name:
                    names.append(comp_name)

        return names

    def _extract_sterilization_method(self, recipe: dict) -> str | None:
        """Extract sterilization method."""
        sterilization = recipe.get("sterilization")
        if sterilization and isinstance(sterilization, dict):
            return sterilization.get("method")
        return None

    def _extract_media_database(self, recipe: dict) -> str | None:
        """Extract media database source (DSMZ, TOGO, etc.)."""
        media_term = recipe.get("media_term", {})
        if isinstance(media_term, dict):
            term = media_term.get("term", {})
            if isinstance(term, dict):
                term_id = term.get("id", "")
                if ":" in term_id:
                    return term_id.split(":")[0]
        return None

    def _extract_media_database_id(self, recipe: dict) -> str | None:
        """Extract full media database ID."""
        media_term = recipe.get("media_term", {})
        if isinstance(media_term, dict):
            term = media_term.get("term", {})
            if isinstance(term, dict):
                return term.get("id")
        return None

    def export(self, output_path: Path) -> None:
        """Export to JavaScript data file."""
        browser_data = self.extract_browser_data()

        # Generate JavaScript file
        js_content = "// CultureMech Browser Data\n"
        js_content += "// Auto-generated - do not edit manually\n\n"
        js_content += f"window.culturemechData = {json.dumps(browser_data, indent=2)};\n\n"
        js_content += "// Dispatch event to notify that data is ready\n"
        js_content += "dispatchEvent(new CustomEvent('culturemechDataReady'));\n"

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(js_content)

        if output_path.name == "data.js":
            json_path = output_path.parent / "recipes.json"
            json_path.write_text(json.dumps(browser_data, indent=2), encoding="utf-8")

            tsv_path = output_path.parent / "recipes.tsv"
            columns = [
                "id",
                "name",
                "category",
                "medium_type",
                "physical_state",
                "media_database",
                "media_database_id",
                "num_ingredients",
                "num_solutions",
                "num_preparation_steps",
                "ph_value",
                "ph_range",
                "high_metal",
                "high_ree",
                "sterilization_method",
                "target_organism_names",
                "organism_ids",
                "ingredient_names",
                "applications",
                "html_page",
            ]
            with open(tsv_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(columns)
                for row in browser_data:
                    writer.writerow(
                        [
                            (
                                "; ".join(str(x) for x in row.get(col, []))
                                if isinstance(row.get(col), list)
                                else ("" if row.get(col) is None else str(row.get(col)))
                            )
                            for col in columns
                        ]
                    )

        print(f"✓ Exported {len(browser_data)} recipes to {output_path}")


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Export CultureMech recipes to browser data format"
    )
    parser.add_argument(
        "-i",
        "--input",
        type=Path,
        default="data/normalized_yaml",
        help="Input directory containing normalized recipe YAML files (Layer 3)",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default="app/data.js",
        help="Output JavaScript file",
    )

    args = parser.parse_args()

    exporter = BrowserExporter(args.input)
    exporter.load_recipes()
    exporter.export(args.output)


if __name__ == "__main__":
    main()
