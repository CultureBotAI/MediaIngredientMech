"""
UMAP visualization generator for culture media embeddings.

Orchestrates the full pipeline: loading, aggregation, reduction, and HTML generation.
"""

from pathlib import Path

import yaml
from jinja2 import Environment, FileSystemLoader, select_autoescape

from culturemech.embedding.aggregator import MediaEmbedding
from culturemech.embedding.aggregator_yaml_source import MediaVectorAggregatorYAML
from culturemech.embedding.dimensionality import reduce_to_2d
from culturemech.embedding.loader import EmbeddingLoader


class UMAPVisualizationGenerator:
    """Generate interactive UMAP visualizations of media embeddings."""

    def generate_both_plots(
        self,
        media_dir: Path,
        embeddings_path: Path,
        output_html: Path,
        cache_dir: Path = Path(".umap_cache"),
        force_reload: bool = False,
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        min_coverage: float = 0.5,
        method: str = "pacmap",
    ) -> None:
        """
        Generate interactive UMAP visualization with both derived and direct embeddings.

        Args:
            media_dir: Directory containing media YAML files
            embeddings_path: Path to KG-Microbe embeddings TSV.gz
            output_html: Path for output HTML file
            cache_dir: Directory for caching embeddings
            force_reload: Force reload from source (bypass cache)
            n_neighbors: UMAP n_neighbors parameter
            min_dist: UMAP min_dist parameter
            min_coverage: Minimum embedding coverage for derived embeddings
            method: 2D reducer to use, one of "pacmap" (default) or "umap"
        """
        print("=" * 70)
        print("UMAP Visualization Generator - CultureMech")
        print("=" * 70)

        # Step 1: Load embeddings
        print("\n[1/6] Loading embeddings...")
        embeddings = EmbeddingLoader.load_embeddings(
            embeddings_path=embeddings_path,
            node_prefixes=[
                "CHEBI",
                "NCBITaxon",
                "mediadive.medium",
                "mediadive.solution",
                "FOODON",
                "mediadive.ingredient",
                "mediadive.compound",
            ],
            cache_dir=cache_dir,
            force_reload=force_reload,
        )

        # Step 2: Collect media YAML files
        print("\n[2/6] Collecting media files...")
        media_yamls = self._collect_media_yamls(media_dir)
        print(f"✓ Found {len(media_yamls):,} media YAML files")

        # Step 3: Generate derived embeddings
        print("\n[3/6] Aggregating derived embeddings...")
        aggregator = MediaVectorAggregatorYAML(
            embeddings,
            solution_mapping_path=Path("data/solution_to_chebi_mapping.json"),
            name_mapping_path=Path("data/chemical_name_to_chebi_mapping_enhanced.json"),
        )
        derived_embeddings = aggregator.aggregate_derived_embeddings(
            media_yamls, min_coverage=min_coverage
        )

        # Step 4: Extract direct embeddings
        print("\n[4/6] Extracting direct embeddings...")
        direct_embeddings = aggregator.get_direct_embeddings(media_yamls)

        # Step 5: Apply 2D reduction (PaCMAP by default, UMAP optional)
        print(f"\n[5/6] Applying 2D reduction ({method})...")
        derived_df = reduce_to_2d(
            derived_embeddings, n_neighbors=n_neighbors, min_dist=min_dist, method=method
        )
        direct_df = reduce_to_2d(
            direct_embeddings, n_neighbors=n_neighbors, min_dist=min_dist, method=method
        )

        # Step 6: Generate HTML visualization
        print("\n[6/6] Generating HTML visualization...")
        self._generate_html(
            derived_df=derived_df,
            direct_df=direct_df,
            derived_embeddings=derived_embeddings,
            direct_embeddings=direct_embeddings,
            media_dir=media_dir,
            output_html=output_html,
        )

        print("\n" + "=" * 70)
        print(f"✓ Visualization generated: {output_html}")
        print(f"  - Derived embeddings: {len(derived_embeddings):,} media")
        print(f"  - Direct embeddings: {len(direct_embeddings):,} media")
        print("=" * 70)

    def _collect_media_yamls(self, media_dir: Path) -> list[Path]:
        """
        Collect all media and solution YAML files from directory tree.

        Includes:
        - Media files from category subdirectories (bacterial, fungal, etc.)
        - Solution files from solutions/mediadive/ directory

        Returns list with all YAML paths sorted by name.
        """
        media_yamls = []

        # Collect media from category directories
        for category_dir in media_dir.iterdir():
            if category_dir.is_dir() and category_dir.name != "solutions":
                media_yamls.extend(category_dir.glob("*.yaml"))

        # Collect solutions from solutions directory
        solutions_dir = media_dir / "solutions" / "mediadive"
        if solutions_dir.exists():
            media_yamls.extend(solutions_dir.glob("*.yaml"))
            print(f"  + Found {len(list(solutions_dir.glob('*.yaml')))} solution files")

        return sorted(media_yamls)

    def _generate_html(
        self,
        derived_df,
        direct_df,
        derived_embeddings: dict[str, MediaEmbedding],
        direct_embeddings: dict[str, MediaEmbedding],
        media_dir: Path,
        output_html: Path,
    ) -> None:
        """Generate HTML file with embedded D3.js visualization."""
        # Build data structures with metadata
        derived_data = self._build_plot_data(derived_df, derived_embeddings, media_dir)
        direct_data = self._build_plot_data(direct_df, direct_embeddings, media_dir)

        # Load template
        template_dir = Path(__file__).parent.parent / "templates"
        env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(["html"]),
        )
        template = env.get_template("media_umap.html")

        # Unique media count: IDs present in either panel (no double-counting)
        derived_ids = {d["id"] for d in derived_data}
        direct_ids = {d["id"] for d in direct_data}
        unique_count = len(derived_ids | direct_ids)

        # Render template
        html_content = template.render(
            derived_data=derived_data,
            direct_data=direct_data,
            derived_count=len(derived_data),
            direct_count=len(direct_data),
            unique_count=unique_count,
        )

        # Write output
        output_html.parent.mkdir(parents=True, exist_ok=True)
        with open(output_html, "w") as f:
            f.write(html_content)

        print(f"✓ HTML generated: {output_html} ({len(html_content):,} bytes)")

    def _build_plot_data(
        self, df, embeddings: dict[str, MediaEmbedding], media_dir: Path
    ) -> list[dict]:
        """Build plot data structure with metadata for each medium/solution."""
        plot_data = []

        for _, row in df.iterrows():
            medium_id = row["medium_id"]
            embedding = embeddings[medium_id]

            # Load YAML for metadata
            metadata = self._extract_metadata(medium_id, media_dir)

            # Determine entity type (medium vs solution)
            entity_type = metadata.get("entity_type", "medium")

            plot_data.append(
                {
                    "id": medium_id,
                    "x": float(row["umap_x"]),
                    "y": float(row["umap_y"]),
                    "name": metadata.get("name", medium_id),
                    "entity_type": entity_type,  # NEW: medium vs solution
                    "category": metadata.get("category", "unknown"),
                    "medium_type": metadata.get("medium_type", "unknown"),
                    "physical_state": metadata.get("physical_state", "unknown"),
                    "num_ingredients": embedding.num_ingredients,
                    "num_organisms": embedding.num_organisms,
                    "coverage": round(embedding.coverage, 2),
                    "source_database": metadata.get("source_database", "unknown"),
                    "url": f"pages/{medium_id}.html",
                }
            )

        return plot_data

    def _extract_metadata(self, medium_id: str, media_dir: Path) -> dict:
        """Extract metadata from media or solution YAML file.

        Solutions are identified by the ``mediadive_`` id prefix (every such
        record carries a ``mediadive.solution:`` term). They are tagged
        ``entity_type: solution`` regardless of which directory the YAML lives
        in — the MediaDive solution YAMLs are currently materialised under the
        ``bacterial/`` category dir, not the (legacy/empty)
        ``solutions/mediadive/`` path the importer once used.
        """
        is_solution = medium_id.startswith("mediadive_")

        # Search the legacy solutions dir first, then the category dirs.
        candidates = [media_dir / "solutions" / "mediadive" / f"{medium_id}.yaml"]
        for category_dir in sorted(media_dir.iterdir()):
            if category_dir.is_dir() and category_dir.name != "solutions":
                candidates.append(category_dir / f"{medium_id}.yaml")

        for yaml_path in candidates:
            if not yaml_path.exists():
                continue
            try:
                with open(yaml_path) as f:
                    data = yaml.safe_load(f) or {}
            except Exception:
                continue

            if is_solution:
                return {
                    "name": data.get("preferred_term", medium_id),
                    "entity_type": "solution",
                    "category": "solution",
                    "medium_type": "solution",
                    "physical_state": "solution",
                    "source_database": "mediadive",
                }
            return {
                "name": data.get("name", medium_id),
                "entity_type": "medium",
                "category": yaml_path.parent.name,
                "medium_type": data.get("medium_type", "unknown"),
                "physical_state": data.get("physical_state", "unknown"),
                "source_database": self._infer_source_database(data),
            }

        return {"entity_type": "solution" if is_solution else "medium"}

    def _infer_source_database(self, media_data: dict) -> str:
        """Infer source database from media term ID."""
        media_term = media_data.get("media_term")
        if isinstance(media_term, dict) and "term" in media_term:
            term = media_term["term"]
            if isinstance(term, dict) and "id" in term:
                term_id = term["id"]
                if ":" in term_id:
                    return term_id.split(":")[0]
        return "unknown"
