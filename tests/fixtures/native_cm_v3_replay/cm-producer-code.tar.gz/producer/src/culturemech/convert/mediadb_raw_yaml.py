"""Convert MediaDB SQL/JSON to raw YAML format.

Performs direct 1:1 conversion of MediaDB exports to YAML
without any normalization or LinkML validation.

Input: raw/mediadb/*.json (or *.sql converted to JSON)
Output: raw_yaml/mediadb/*.yaml
"""

import argparse
import logging
from pathlib import Path

from culturemech.convert.base import JSONToRawYAMLConverter, add_batch_arguments, batch_options

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Convert MediaDB JSON to raw YAML format (no normalization)"
    )
    parser.add_argument(
        "-i",
        "--input",
        type=Path,
        default="data/raw/mediadb",
        help="Input directory with MediaDB JSON files (default: raw/mediadb)",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default="data/raw_yaml/mediadb",
        help="Output directory for raw YAML files (default: raw_yaml/mediadb)",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")

    add_batch_arguments(parser)
    args = parser.parse_args()

    logger.info("Converting MediaDB JSON to raw YAML")
    logger.info(f"  Input: {args.input}")
    logger.info(f"  Output: {args.output}")

    converter = JSONToRawYAMLConverter(verbose=args.verbose)
    converter.convert_directory(args.input, args.output, pattern="*.json", **batch_options(args))

    logger.info("Conversion complete")


if __name__ == "__main__":
    main()
